### AUTHORS

Many people contributed for this release, some did so years ago, when
they made the sprites present here available free of charge. In
alphabetical order:

- 2Rec - [@OTLand](https://otland.net/members/2rec.187741/);
- 3visan (aka Vittu) - [@TibiaKing](http://www.tibiaking.com/forum/profile/19276-3visan/);
- Anevis (aka Caynez) - [@OTLand](https://otland.net/members/anevis.175097/), [@OTRealm](https://otrealm.com/index.php?members/caynez.51/);
- Andreéw - [@OTLand](https://otland.net/members/andreew.211874/);
- Arkan'. - [@OTLand](https://otland.net/members/arkan.214264/);
- BeachboyX - [@OTRealm](https://sprites.otrealm.com/);
- BrenoNeto - [@XTibia](http://www.xtibia.com/forum/profile/356307-brenoneto/);
- Cat - [@ZezeniaForum](https://www.zezeniaonline.com/forum/thread/15599);
- Celix - [@PhobosForum](http://forum.phobosonline.com/memberlist.php?mode=viewprofile&u=20);
- Corvo (aka handland) - [@OTLand](https://otland.net/members/handland1.225765/);
- dami1310 - [@OTLand](https://otland.net/members/dami1310.174641/);
- Daniel - [@OTRealm](https://sprites.otrealm.com/), [@TibiaKing](http://www.tibiaking.com/forum/profile/25583-daniel/);
- DawTorr - [@OTLand](https://otland.net/members/dawtorr.200757/);
- Despute - [@OTLand](https://otland.net/members/despute.212598/);
- ElderDark - [@TibiaKing](http://www.tibiaking.com/forum/profile/24698-elderdark/);
- Erick Etchebeur - [@OTRealm](https://otrealm.com/index.php?members/erick-etchebeur.7/), [@OTLand](https://otland.net/members/erick-etchebeur.212333/);
- Frevius - [@XTibia](http://www.xtibia.com/forum/profile/41440-frenvius/);
- Galiant (aka Andre) - [@OTLand](https://otland.net/members/galiant.211412/);
- GhostX - [@OTLand](https://otland.net/members/ghostx.145618/);
- HalfAway - [@OTLand](https://otland.net/members/halfaway.142275/), [@OTRealm](https://otrealm.com/index.php?members/halfaway.1/);
- Hunter Killer (aka Made of Clay) - [@OpenTibia](https://opentibia.net/topic/129940-who-deleted-my-thead/);
- Jacobs - [@OTLand](https://otland.net/members/jacobs.203121/);
- Landera - [@OTLand](https://otland.net/members/landera.146831/);
- Leshrot - [@OTLand](https://otland.net/members/leshrot.169503/), [@TibiaKing](http://www.tibiaking.com/forum/profile/40651-leshrot/), [@XTibia](http://www.xtibia.com/forum/profile/388631-leshrot/), [@OTRealm](https://otrealm.com/index.php?members/leshrot.50/);
- lionkobin - [@XTibia](http://www.xtibia.com/forum/profile/294150-lionkobin/);
- Madarada - [@OTLand](https://otland.net/members/madarada.222164/), [@XTibia](http://www.xtibia.com/forum/profile/379350-madarada/), [@TibiaKing](http://www.tibiaking.com/forum/profile/106486-madarada/);
- markindoot - [@XTibia](http://www.xtibia.com/forum/profile/357805-markindoot/);
- maxmillerxd - [@TibiaKing](http://www.tibiaking.com/forum/profile/15396-maxmillerxd/);
- Nechros - [@TibiaKing](http://www.tibiaking.com/forum/profile/40715-nechros/);
- Nogard - [@TibiaKing](http://www.tibiaking.com/forum/profile/38543-nogard/), [@XTibia](http://www.xtibia.com/forum/profile/397698-nogard/);
- Nordberg - [@PhobosForum](http://forum.phobosonline.com/memberlist.php?mode=viewprofile&u=126);
- Noxz - [@OTLand](https://otland.net/members/noxz.6166/);
- Nu77 - [@OTLand](https://otland.net/members/nu77.204078/);
- Peonso - [@OTLand](https://otland.net/members/peonso.5289/);
- Ranzor - [@OTLand](https://otland.net/members/ranzor.217381/);
- Sam Drost - [@OTLand](https://otland.net/members/sam-drost.223008/);
- Saphron - [@OTLand](https://otland.net/members/saphron.91841/), [@OTRealm](https://otrealm.com/index.php?members/saphron.14/);
- Sherice - [@OTLand](https://otland.net/members/sherice.150418/);
- Shiva Shadowsong - [@OTLand](https://otland.net/members/shadowsong.78705/), [@OTRealm](https://otrealm.com/index.php?members/shiva-shadowsong.15/);
- Slaake - [@TibiaKing](http://www.tibiaking.com/forum/profile/35794-slaake/);
- Somni - [@OTLand](https://otland.net/members/somni.6137/);
- Thorn - [@OTLand](https://otland.net/members/thorn.166053/), [@OTRealm](https://otrealm.com/index.php?members/thorn.130/);
- Tokume - [@PhobosForum](http://forum.phobosonline.com/memberlist.php?mode=viewprofile&u=1484);
- Venesis - [@OTLand](https://otland.net/members/venesis.23089/);
- wesleyt10 - [@XTibia](http://www.xtibia.com/forum/profile/360593-wesleyt10/);
- Way20 - [@OTLand](https://otland.net/threads/way-gallery.224923/);
- Weto - [@OTLand](https://otland.net/members/weto.209826/), [@TibiaKing](http://www.tibiaking.com/forum/profile/28864-ewerton-weto-costa/), [@XTibia](http://www.xtibia.com/forum/profile/226928-eltoo/);
- Worr - [@OTLand](https://otland.net/members/worr.110421/);

Some people didn't make the sprites themselves, but paid for them and made them available. The artist is already credited above, here the list of Mecenas:
- Sajgon - [@OTLand](https://otland.net/members/sajgon.221620/);